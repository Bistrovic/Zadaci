﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1252025
{
    public partial class Form1 : Form
    {
        private UdpClient udpServer;
        private CancellationTokenSource cts;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tekst = textBox1.Text;
            listBox1.Items.Add(tekst);
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    string ip = listBox1.Items[i].ToString();

                    for (int port = int.Parse(portpoc.Text); port < int.Parse(portkr.Text); port++)
                    {
                        try
                        {
                            using (TcpClient client = new TcpClient())
                            {
                                await client.ConnectAsync(ip, port);
                                using (NetworkStream stream = client.GetStream())
                                {
                                    string message = "y";
                                    byte[] data = Encoding.UTF8.GetBytes(message);
                                    await stream.WriteAsync(data, 0, data.Length);

                                    this.Invoke((MethodInvoker)(() =>
                                    {
                                        label3.Text = "Poruka poslana!";
                                        label4.Text = port.ToString();
                                        label5.Text = ip;
                                        MessageBox.Show("Pronađen");
                                    }));
                                }
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
            else if (radioButton1.Checked)
            {
                string slanje = "y";
                string primanje = "x";

                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    string ip = listBox1.Items[i].ToString();

                    for (int port = int.Parse(portpoc.Text); port < int.Parse(portkr.Text); port++)
                    {
                        await Task.Run(() => ScanUdp(ip, port, slanje, primanje));
                    }
                }
            }
        }

        private void ScanUdp(string ip, int port, string message, string expectedResponse)
        {
            try
            {
                using (UdpClient send = new UdpClient())
                using (UdpClient receive = new UdpClient(port + 1))
                {
                    receive.Client.ReceiveTimeout = 2000;

                    IPEndPoint target = new IPEndPoint(IPAddress.Parse(ip), port);
                    byte[] data = Encoding.ASCII.GetBytes(message);
                    send.Send(data, data.Length, target);

                    IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);
                    byte[] response = receive.Receive(ref remoteEP);
                    string responseStr = Encoding.ASCII.GetString(response);

                    if (responseStr.Trim() == expectedResponse)
                    {
                        Invoke(new Action(() =>
                        {
                            label3.Text = "Poruka poslana!";
                            label4.Text = port.ToString();
                            label5.Text = ip;
                            MessageBox.Show("Pronađen");
                        }));
                    }
                }
            }
            catch
            {
            }
        }


        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            cts?.Cancel();
            udpServer?.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }
    }
}
