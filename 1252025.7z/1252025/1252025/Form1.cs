﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
namespace _1252025
{
   
    public partial class Form1 : Form
    {
        private UdpClient udpClient = new UdpClient();
        private UdpClient udpServer;

        public Form1()
        {
            InitializeComponent();
            udpServer = new UdpClient(port);
            Task.Run(() => Listen());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tekst = textBox1.Text;
            listBox1.Items.Add(tekst);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    string ip = listBox1.Items[i].ToString();

                    for (int port = int.Parse(portpoc.Text); port < int.Parse(portkr.Text); port++)
                    {
                        try
                        {
                            using (TcpClient client = new TcpClient())
                            {
                                client.Connect(ip, port);
                                using (NetworkStream stream = client.GetStream())
                                {
                                    string message = "Test poruka";
                                    byte[] data = Encoding.UTF8.GetBytes(message);
                                    stream.Write(data, 0, data.Length);
                                    label3.Text = "Poruka poslana!";
                                    label4.Text = port.ToString();
                                    label5.Text = ip;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ;
                        }
                    }
                }
            }
            else if(radioButton1.Checked){
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    string ip = listBox1.Items[i].ToString();

                    for (int port = int.Parse(portpoc.Text); port < int.Parse(portkr.Text); port++)
                    {
                        try
                        {
                            string message = "Test poruka!";
                            byte[] data = Encoding.UTF8.GetBytes(message);
                            udpClient.Send(data, data.Length, ip, port);

                        }
                        catch (Exception ex)
                        {
                            ;
                        }
                    }
                }
            }
       
          
        }
    }
}
