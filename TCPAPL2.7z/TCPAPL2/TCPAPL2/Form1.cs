﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCPAPL2
{
    public partial class Form1 : Form
    {
        private TcpListener server;
        private const int port = 5000;

        public Form1()
        {
            InitializeComponent();
            StartServer();
        }

        private void StartServer()
        {
            server = new TcpListener(IPAddress.Parse("127.0.0.1"), port); // Eksplicitno postavi IP
            server.Start();
            listBox1.Items.Add("Server pokrenut...");

            Task.Run(() => ListenForClients()); // Asinkrono prihvaćaj klijente
        }

        private async void ListenForClients()
        {
            while (true)
            {
                TcpClient client = await server.AcceptTcpClientAsync();
                HandleClient(client);
            }
        }

        private async void HandleClient(TcpClient client)
        {
            try
            {
                using (NetworkStream stream = client.GetStream())
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    Invoke((MethodInvoker)(() => listBox1.Items.Add("Primljeno: " + message)));
                }
            }
            catch (Exception ex)
            {
                Invoke((MethodInvoker)(() => listBox1.Items.Add("Greška: " + ex.Message)));
            }
            finally
            {
                client.Close();
            }
        }
    }
}
