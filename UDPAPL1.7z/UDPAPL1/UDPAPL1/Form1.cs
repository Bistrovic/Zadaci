﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UDPAPL1
{
    public partial class Form1 : Form
    {
        private UdpClient udpServer;
        private const int port = 5000;

        public Form1()
        {
            InitializeComponent();
            udpServer = new UdpClient(port);
            Task.Run(() => Listen());
        }

        private void Listen()
        {
            IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, port);
            while (true)
            {
                try
                {
                    byte[] data = udpServer.Receive(ref remoteEP);
                    string message = Encoding.UTF8.GetString(data);

                    this.Invoke((MethodInvoker)(() =>
                    {
                        listBox1.Items.Add($"Primljeno: {message}");
                    }));
                }
                catch
                {
                    // Ignoriraj greške
                }
            }
        }
    }
}
