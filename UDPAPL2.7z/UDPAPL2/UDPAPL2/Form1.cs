﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace UDPAPL2
{
    public partial class Form1 : Form
    {
        private UdpClient udpClient = new UdpClient();
        private Timer timer = new Timer();
        private int brojac = 0;
        private const string ip = "127.0.0.1";
        private const int port = 5000;

        public Form1()
        {
            InitializeComponent();
            timer.Interval = 1000; // 1 sekunda
            timer.Tick += Timer_Tick;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            brojac++;
            string message = brojac.ToString();
            byte[] data = Encoding.UTF8.GetBytes(message);
            udpClient.Send(data, data.Length, ip, port);
            listBox1.Items.Add($"Poslano: {message}");
        }
    }
}
