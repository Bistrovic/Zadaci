﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace TCPAPL1
{
    public partial class Form1 : Form
    {
        private const string ip = "127.0.0.1";
        private const int port = 5000;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                using (TcpClient client = new TcpClient())
                {
                    client.Connect(ip, port); // Eksplicitno postavi IP i port
                    using (NetworkStream stream = client.GetStream())
                    {
                        string message = "Test poruka";
                        byte[] data = Encoding.UTF8.GetBytes(message);
                        stream.Write(data, 0, data.Length);
                        listBox1.Items.Add("Poruka poslana!");
                    }
                }
            }
            catch (Exception ex)
            {
                listBox1.Items.Add("Greška: " + ex.Message);
            }
        }
    }
}
